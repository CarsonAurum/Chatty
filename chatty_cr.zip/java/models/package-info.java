/**
 * Model classes.
 */
package models;