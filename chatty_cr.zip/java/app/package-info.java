/**
 * Classes relating to the general function of this application.
 */
package app;